# Medical Example
This example shows how to import medical imaging data (in the form of a folder of 2D image slices) and perfomantly display and manipulate it on HoloLens.

It can be easily extended to import other formats and can serve as the basis for a medical application.
